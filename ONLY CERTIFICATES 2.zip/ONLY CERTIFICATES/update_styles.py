import os
import glob
import re

base_dir = "/Users/abhinavvishwakarma/Desktop/Gr-class-Workshop/Gr-Class-Backend/ONLY CERTIFICATES"

new_style = """<style>
        /* ── OPTIMIZED CSS (SYSTEM FONTS FOR INSTANT LOAD) ── */
        :root {
            --navy-blue: #0b2545;
            --navy-light: #133c6d;
            --gold-primary: #b08d57;
            --text-dark: #1a1a1a;
            --text-muted: #444444;
            --paper: #ffffff;
            --stamp-color: #E65100; /* Bhagwa Color */
            --bg-light: #f4f6f8;
            --primary: #0b2545;
            --border: #ccc;
            --light: #f4f6f8;
        }

        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            font-size: 7.8pt; /* Compact font size to prevent overflow */
            background: #222;
            padding: 20px 0 40px;
            color: var(--text-dark);
            line-height: 1.3;
        }

        .no-print {
            width: 210mm;
            margin: 0 auto 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            padding: 12px 20px;
            border-radius: 4px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }

        .btn-print {
            background: var(--gold-primary);
            color: #fff;
            border: none;
            padding: 8px 18px;
            font-size: 8.5pt;
            font-weight: bold;
            cursor: pointer;
            border-radius: 3px;
            text-transform: uppercase;
        }
        .btn-print:hover { background: #967645; }
        .tag-hint { font-size: 7.5pt; color: #666; font-style: italic; }

        /* ── CERTIFICATE DESIGN (A4) ── */
        .cert-page {
            width: 210mm;
            height: 297mm;
            background-color: var(--paper);
            margin: 0 auto 15mm auto;
            position: relative;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            padding: 8mm; /* Margins slightly reduced for extra height room */
            display: flex;
            flex-direction: column;
            overflow: hidden; /* Prevent borders from overflowing if content gets too large */
        }

        /* Double Border System */
        .border-outer {
            border: 2.5px solid var(--navy-blue);
            flex: 1; /* Allow flex to fit the 297mm cert-page */
            display: flex;
            flex-direction: column;
            padding: 3px;
            position: relative;
            min-height: 0; /* Important for flex children to not overflow */
        }
        .border-inner {
            border: 1px solid var(--gold-primary);
            flex: 1;
            padding: 7mm 7mm 8.5mm 7mm; /* Inner padding slightly reduced */
            display: flex;
            flex-direction: column;
            position: relative;
            min-height: 0;
        }

        /* Background Watermark */
        .watermark {
            position: absolute;
            top: 50%; left: 50%;
            transform: translate(-50%, -50%) rotate(-30deg);
            font-family: 'Georgia', serif;
            font-size: 80pt;
            color: var(--navy-blue);
            opacity: 0.025;
            font-weight: bold;
            text-align: center;
            line-height: 1;
            pointer-events: none;
            white-space: nowrap;
            z-index: 0;
        }

        /* ── HEADER ── */
        .cert-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            border-bottom: 2px solid var(--gold-primary);
            padding-bottom: 2mm;
            margin-bottom: 2.5mm;
            z-index: 1;
            flex-shrink: 0;
        }
        
        .hdr-left { flex: 0 0 85px; text-align: left; }
        .hdr-left img { max-width: 80px; height: auto; object-fit: contain; }
        .logo-fallback {
            width: 65px; height: 65px;
            border: 2px solid var(--navy-blue); border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-family: 'Times New Roman', serif; font-weight: bold; font-size: 16pt; color: var(--navy-blue);
        }

        .hdr-center { flex: 1; text-align: center; padding: 0 10px; }
        .hdr-flag {
            font-family: 'Times New Roman', serif;
            font-size: 12.5pt;
            font-weight: bold;
            color: var(--text-dark);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 3px;
        }
        .hdr-title-es {
            font-family: 'Georgia', serif;
            font-size: 9.5pt;
            font-weight: bold;
            color: var(--navy-blue);
            margin-bottom: 1px;
            text-transform: uppercase;
        }
        .hdr-title-en {
            font-family: 'Georgia', serif;
            font-size: 11.5pt;
            font-weight: bold;
            color: var(--navy-blue);
            margin-bottom: 2px;
            text-transform: uppercase;
        }
        .hdr-convention {
            font-family: 'Times New Roman', serif;
            font-size: 7.2pt;
            color: var(--text-muted);
            line-height: 1.25;
            font-style: italic;
        }

        .hdr-right { flex: 0 0 auto; text-align: right; min-width: 120px; }
        .hdr-meta-label { font-size: 6pt; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; }
        .hdr-meta-no {
            font-family: 'Courier New', monospace;
            font-size: 10pt;
            font-weight: bold;
            color: var(--stamp-color);
            margin-top: 1px;
            display: block;
        }
        .hdr-meta-form { font-size: 6pt; color: var(--navy-blue); margin-top: 2px; font-weight: bold; }

        /* ── AUTHORITY ── */
        .authority {
            text-align: center;
            font-family: 'Times New Roman', serif;
            font-size: 8.5pt;
            color: var(--text-dark);
            line-height: 1.35;
            padding-bottom: 2mm;
            border-bottom: 1px solid #ddd;
            margin-bottom: 2.5mm;
            z-index: 1;
            flex-shrink: 0;
        }
        .authority strong { color: var(--navy-blue); text-transform: uppercase; }

        /* ── SECTIONS & TABLES ── */
        .sec-label {
            font-family: 'Arial', sans-serif;
            font-size: 7.2pt;
            font-weight: bold;
            color: var(--navy-light);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin: 2mm 0 1mm 0;
            border-left: 3px solid var(--gold-primary);
            padding-left: 5px;
            z-index: 1;
        }

        /* Data table & Vessel table styling combined */
        .data-table, .vtable, .mtable {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 2mm;
            table-layout: fixed; /* Fixes horizontal overflow */
            z-index: 1;
            flex-shrink: 0;
        }
        .data-table th, .data-table td, .vtable th, .vtable td, .mtable th, .mtable td {
            border: 1px solid #ccc;
            padding: 2px 4px; /* Compact padding */
            text-align: left;
            word-wrap: break-word; /* Wraps long content */
            overflow-wrap: break-word;
        }
        .data-table th, .vtable th, .mtable th {
            background: var(--bg-light);
            font-size: 6pt;
            text-transform: uppercase;
            color: var(--text-muted);
            line-height: 1.2;
        }
        .data-table td, .vtable td, .mtable td {
            font-family: 'Times New Roman', serif;
            font-size: 8pt; /* Compact font size */
            font-weight: bold;
            color: var(--navy-blue);
            vertical-align: middle;
        }
        
        .val, .m-val {
            font-family: 'Times New Roman', serif;
            font-size: 8.5pt;
            font-weight: bold;
            color: var(--navy-blue);
        }
        
        .val-large {
            font-size: 13pt !important;
            text-align: center;
            padding: 6px !important;
        }

        /* Checkbox items */
        .chk-list { display: flex; flex-direction: column; gap: 1.5px; margin-bottom: 1.5mm; z-index: 1; flex-shrink: 0; }
        .chk-item {
            display: flex; align-items: flex-start; gap: 5px;
            padding: 1px 3px; border: 1px solid transparent;
            font-size: 7.2pt; line-height: 1.3; color: var(--text-dark);
        }
        .chk-item.checked { background: var(--bg-light); border-color: var(--border); font-weight: 500; }
        .checkbox {
            width: 9px; height: 9px; border: 1px solid var(--navy-blue); flex-shrink: 0; margin-top: 1.5px;
            background: #fff; position: relative;
        }
        .chk-item.checked .checkbox { background: var(--navy-blue); }
        .chk-item.checked .checkbox::after {
            content: ''; position: absolute; left: 1.5px; top: 0;
            width: 3.5px; height: 5px;
            border-right: 1.2px solid #fff; border-bottom: 1.2px solid #fff;
            transform: rotate(38deg);
        }
        .chk-text b { color: var(--navy-blue); }
        .inline-val {
            display: inline-block; font-family: 'Times New Roman', serif;
            font-size: 9pt; font-weight: bold; color: var(--navy-blue);
            border-bottom: 1px dashed var(--navy-blue);
            padding: 0 2px; min-width: 50px; line-height: 1.1; vertical-align: bottom;
        }

        /* ── FOOTNOTES & PARAGRAPHS ── */
        .footnotes {
            font-family: 'Arial', sans-serif;
            font-size: 6pt;
            color: #666;
            line-height: 1.25;
            margin-bottom: 2mm;
            z-index: 1;
            flex-shrink: 0;
        }
        .footnotes p { margin-bottom: 1px; }
        sup { color: var(--navy-blue); font-weight: bold; font-size: 5.5pt; }

        .certify-box, .certify {
            border: 1px solid #ccc;
            border-left: 4.5px solid var(--navy-blue);
            background: var(--bg-light);
            padding: 5px 8px;
            font-family: 'Times New Roman', serif;
            font-size: 8.5pt;
            line-height: 1.35;
            margin-bottom: 2.5mm;
            text-align: justify;
            z-index: 1;
            flex-shrink: 0;
        }
        .certify-box i { color: var(--text-muted); font-size: 8pt; display: block; margin-top: 2px; }
        .certify-title {
            font-weight: bold; color: var(--navy-blue); font-size: 8.5pt;
            margin-bottom: 2px; text-transform: uppercase; letter-spacing: .5px;
        }
        .certify ul { margin-left: 14px; }
        .certify ul li { margin-bottom: 1.5px; }

        /* ── VALIDITY GRID ── */
        .vgrid {
            display: flex;
            justify-content: space-between;
            border: 1px solid var(--gold-primary);
            background: #fdfbf7;
            padding: 5px 10px;
            margin-bottom: 2.5mm;
            z-index: 1;
            flex-shrink: 0;
        }
        .vgrid-2 {
            display: flex;
            justify-content: space-between;
            border: 1px solid var(--border);
            background: #ffffff;
            padding: 4px 10px;
            margin-bottom: 2.5mm;
            z-index: 1;
            flex-shrink: 0;
        }
        .vcell { text-align: left; }
        .vcell-label, .vc-label { font-size: 6pt; color: var(--text-muted); text-transform: uppercase; margin-bottom: 1px; display: block; }
        .vcell-val, .vc-val { font-family: 'Courier New', monospace; font-size: 9pt; font-weight: bold; color: var(--navy-blue); }

        /* ── FOOTER AREA ── */
        .footer-area {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: auto;
            padding-top: 1mm;
            z-index: 1;
            flex-shrink: 0;
        }

        /* DIAMOND STAMP (BHAGWA) */
        .stamp-container {
            position: relative;
            width: 28mm;
            height: 28mm;
            display: flex;
            justify-content: center;
            align-items: center;
            transform: rotate(-10deg);
        }
        .diamond-stamp {
            width: 20mm;
            height: 20mm;
            border: 1.8px solid var(--stamp-color);
            transform: rotate(45deg);
            position: absolute;
            background: radial-gradient(circle at 30% 30%, rgba(255, 255, 255, 0.6) 0%, rgba(255, 255, 255, 0) 60%), rgba(230, 81, 0, 0.05);
            box-shadow: inset 0 0 3px rgba(230, 81, 0, 0.2);
        }
        .diamond-stamp::before {
            content: '';
            position: absolute;
            inset: 1.5px;
            border: 1px dashed rgba(230, 81, 0, 0.5);
        }
        .stamp-text-wrapper {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 26mm;
        }
        .st-top { font-size: 4pt; font-weight: bold; color: var(--stamp-color); letter-spacing: 0.5px; }
        .st-mid { font-family: 'Georgia', serif; font-size: 7.5pt; font-weight: bold; color: var(--stamp-color); border-top: 1px solid var(--stamp-color); border-bottom: 1px solid var(--stamp-color); margin: 1px 0; padding: 0.5px 0; width: 100%; text-align: center; }
        .st-bot { font-size: 5pt; font-weight: bold; color: var(--stamp-color); letter-spacing: 0.5px; }

        .signature-area { width: 50mm; text-align: center; }
        .sig-line { border-bottom: 1px solid var(--text-dark); height: 18px; margin-bottom: 3px; position: relative; }
        .sig-line img { max-height: 25px; position: absolute; bottom: 1px; left: 50%; transform: translateX(-50%); }
        .sig-name { font-family: 'Times New Roman', serif; font-size: 9pt; font-weight: bold; color: var(--navy-blue); }
        .sig-title, .sig-desig { font-size: 6pt; color: var(--text-muted); text-transform: uppercase; }

        .qr-section { display: flex; align-items: center; gap: 4px; text-align: right; font-size: 5.5pt; color: var(--text-muted); line-height: 1.2; }
        .qr-box, .qr-wrap { width: 38px; height: 38px; border: 1px solid #ccc; padding: 2px; }
        .qr-box img, .qr-wrap img { width: 100% !important; height: 100% !important; display: block; }
        .qr-section strong { color: var(--navy-blue); font-size: 7pt; display: block; margin-bottom: 1px; }

        .page-indicator {
            display: flex; justify-content: space-between;
            border-top: 1px solid #eee; padding-top: 1px; margin-top: 2.5mm;
            font-size: 5.5pt; color: #888;
            z-index: 1;
            flex-shrink: 0;
        }

        /* ── PAGE 2 SPECIFIC / ENDORSEMENTS ── */
        .mini-hdr {
            display: flex; justify-content: space-between; align-items: center;
            border-bottom: 1px solid #ccc; padding-bottom: 1.5mm; margin-bottom: 3mm;
            z-index: 1;
            flex-shrink: 0;
        }
        .mini-hdr-left { display: flex; align-items: center; gap: 6px; font-size: 7pt; font-weight: bold; color: var(--navy-blue); }
        .mini-hdr-left img { height: 18px; object-fit: contain; }
        .mini-hdr-right { font-size: 7pt; color: var(--text-muted); }
        .mini-hdr-right span { font-family: 'Courier New', monospace; font-weight: bold; color: var(--navy-blue); }

        .end-title {
            font-family: 'Georgia', serif; font-size: 11pt; font-weight: bold;
            color: var(--navy-blue); text-align: center; margin: 3mm 0 1.5mm;
            z-index: 1;
            flex-shrink: 0;
        }
        .end-subtitle {
            font-size: 7.5pt; color: var(--text-muted); text-align: center; margin-bottom: 3mm;
            padding: 0 8mm; line-height: 1.4;
            z-index: 1;
            flex-shrink: 0;
        }
        .end-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 3mm 5mm;
            margin-bottom: 3mm;
            z-index: 1;
            flex-shrink: 0;
        }
        .end-box {
            border: 1px solid var(--border); background: #fff; padding: 2.5mm;
        }
        .end-box-title {
            font-size: 7pt; font-weight: bold; text-transform: uppercase;
            letter-spacing: 0.5px; color: var(--navy-light); border-bottom: 1px solid var(--border);
            padding-bottom: 1.5px; margin-bottom: 2.5mm;
        }
        .end-row {
            display: flex; align-items: flex-end; margin-bottom: 2.5mm; font-size: 7.2pt;
        }
        .end-label { width: 60px; color: var(--text-muted); }
        .end-line { flex: 1; border-bottom: 1px dashed #ccc; height: 12px; position: relative; }
        .end-line span {
            position: absolute; bottom: 1px; left: 4px; font-family: 'Times New Roman', serif;
            font-size: 9.5pt; font-weight: bold; color: var(--navy-blue);
        }
        .end-full { grid-column: 1 / -1; }

        .gen-notice {
            background: var(--bg-light); border: 1px solid var(--border);
            padding: 2mm 3.5mm; display: flex; align-items: center; justify-content: center;
            gap: 5px; flex-shrink: 0; margin-top: auto; border-radius: 2px;
            z-index: 1;
        }
        .gen-notice-text {
            font-size: 6pt; color: var(--text-muted);
            letter-spacing: .5px; line-height: 1.15; text-align: center; text-transform: uppercase;
        }
        .gen-notice-text strong { color: var(--navy-blue); font-weight: bold; }

        /* 🔹 FIXED PRINT RULES FOR BLANK PDF 🔹 */
        @page { size: A4; margin: 0; }
        @media print {
            html, body {font-size: 7.8pt; 
                background: #fff !important; 
                padding: 0 !important; 
                margin: 0 !important; 
                width: auto !important; 
                height: auto !important;
            }
            .no-print { display: none !important; }
            .cert-page {
                box-shadow: none !important; 
                margin: 0 !important;
                width: 210mm !important; 
                height: 296.5mm !important; /* Slightly below 297 to avoid 1px extra blank page */
                page-break-after: always; 
                page-break-inside: avoid;
                background: white !important;
                position: relative !important;
                overflow: hidden !important;
            }
            .cert-page:last-child { page-break-after: auto; }
        }
    
        /* --- COMPACTING OVERRIDES TO PREVENT OVERFLOW AND BORDER COLLISION --- */
        .no-print + .cert-page h1,
        .no-print + .cert-page h2,
        .no-print + .cert-page h3,
        .no-print + .cert-page h4,
        .no-print + .cert-page h5,
        .no-print + .cert-page h6 {
            margin: 0 !important;
            padding: 0 !important;
            font-weight: bold !important;
            color: var(--navy-blue) !important;
        }
        .no-print + .cert-page h1 { font-size: 9.5pt !important; line-height: 1.15 !important; margin-bottom: 1mm !important; text-align: center !important; }
        .no-print + .cert-page h2 { font-size: 8.5pt !important; line-height: 1.15 !important; margin-bottom: 0.8mm !important; text-align: center !important; }
        .no-print + .cert-page h3 { font-size: 7.8pt !important; line-height: 1.15 !important; margin-bottom: 0.8mm !important; }
        .no-print + .cert-page h4 { font-size: 7.2pt !important; line-height: 1.15 !important; margin-bottom: 0.6mm !important; }
        
        .no-print + .cert-page p,
        .no-print + .cert-page .body p {
            font-size: 7pt !important;
            line-height: 1.2 !important;
            margin-top: 0 !important;
            margin-bottom: 0.4mm !important;
        }
        
        .no-print + .cert-page table p {
            margin: 0 !important;
            padding: 0 !important;
            font-size: inherit !important;
            line-height: inherit !important;
        }
        
        .no-print + .cert-page ol,
        .no-print + .cert-page ul {
            margin-top: 0 !important;
            margin-bottom: 1mm !important;
            padding-left: 3.5mm !important;
        }
        .no-print + .cert-page li {
            font-size: 7pt !important;
            line-height: 1.2 !important;
            margin-bottom: 0.3mm !important;
        }
        
        .no-print + .cert-page table {
            margin-top: 0 !important;
            margin-bottom: 1mm !important;
            border-collapse: collapse !important;
            width: 100% !important;
        }
        .no-print + .cert-page table td,
        .no-print + .cert-page table th {
            padding: 1px 2.5px !important;
            font-size: 7pt !important;
            line-height: 1.15 !important;
        }
        
        .no-print + .cert-page .certify-box,
        .no-print + .cert-page .certify {
            margin-top: 0 !important;
            margin-bottom: 1.5mm !important;
            padding: 3px 5px !important;
            font-size: 7.2pt !important;
            line-height: 1.25 !important;
        }
        
        .no-print + .cert-page .vgrid,
        .no-print + .cert-page .vgrid-2 {
            margin-top: 0 !important;
            margin-bottom: 1.5mm !important;
            padding: 2px 6px !important;
        }
        
        .no-print + .cert-page .authority {
            margin-top: 0 !important;
            margin-bottom: 1.5mm !important;
            padding-bottom: 1mm !important;
            font-size: 7.5pt !important;
            line-height: 1.25 !important;
        }
        
        .no-print + .cert-page .cert-header {
            margin-bottom: 1.5mm !important;
            padding-bottom: 1mm !important;
        }
        
        .no-print + .cert-page .footnotes {
            margin-bottom: 1mm !important;
            font-size: 5.5pt !important;
            line-height: 1.15 !important;
        }
        .no-print + .cert-page .footnotes p {
            margin-bottom: 0.2mm !important;
        }
        
        .no-print + .cert-page .gen-notice {
            margin-top: auto !important;
            margin-bottom: 1mm !important;
            padding: 2px 4px !important;
        }
        .no-print + .cert-page .gen-notice-text {
            font-size: 5.5pt !important;
        }
        
        .no-print + .cert-page .footer-area {
            margin-top: 0 !important;
            padding-top: 0.5mm !important;
        }
        .no-print + .cert-page .sig-line img {
            max-height: 20px !important;
        }
        .no-print + .cert-page .stamp-container {
            width: 24mm !important;
            height: 24mm !important;
        }
        .no-print + .cert-page .diamond-stamp {
            width: 17mm !important;
            height: 17mm !important;
        }
        .no-print + .cert-page .stamp-text-wrapper {
            width: 22mm !important;
        }
        .no-print + .cert-page .st-mid {
            font-size: 6.5pt !important;
        }
        .no-print + .cert-page .qr-box,
        .no-print + .cert-page .qr-wrap {
            width: 32px !important;
            height: 32px !important;
        }
    </style>"""

html_files = glob.glob(os.path.join(base_dir, "**/*.html"), recursive=True)

for file_path in html_files:
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    # Replace the <style>...</style> block
    updated_content = re.sub(r'<style>.*?</style>', new_style, content, flags=re.DOTALL)
    
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(updated_content)
        
print("Successfully updated styles for all HTML files.")
